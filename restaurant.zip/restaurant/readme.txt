Welcome to Fast Food Menu Web Application

To access the web application locally follow the steps:

Step 1: Activate the virtual environment

$ source env/Scripts/activate

Step 2: Install the dependencies from requirements.txt

$ pip install requirements.txt

Step 4: Run the application

$ python app.py

Step 5: Create an account using signup option and login using that account name and password.

Enjoy using the Fast Food Menu Application